package com.example.demo.controller;

import com.example.demo.repository.UserRepository;
import com.example.demo.model.User;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;


import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    // Endpoint to view user profile
    @RequestMapping("/profile/{userId}")
    public String viewUserProfile(@PathVariable(value = "userId") Long userId, Model model) {
        User user = userRepository.getById(userId);

            model.addAttribute("user", user);
            return "userProfile"; // Thymeleaf template name
    }

    // Endpoint to update a user
    @RequestMapping("/edit/{userId}")
    public String updateUser(@PathVariable(value = "userId") Long userId, Model model) {
        Optional<User> user = userRepository.findById(userId);
        if (user.isPresent()) {
            model.addAttribute("user", user.get());
            return "profileEdit"; // Thymeleaf template name
        } else {
            return "UserNotFound"; // Thymeleaf template for handling user not found
        }
    }

    @RequestMapping(value="/save")
    public String saveUpdate(@Valid User user, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            System.out.println(bindingResult.getAllErrors());
            return "profileEdit";
        } else {
            userRepository.save(user);
            return "redirect:/user/profile/" + user.getUserId();
        }
    }

    // Endpoint to delete a user
    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long userId) {
        userRepository.deleteById(userId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

